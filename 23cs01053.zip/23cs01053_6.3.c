#include <stdio.h>
#define  a  2

int main(){


printf("%d\n",a);

printf("%d\n",a);

printf("%d\n",a);

printf("%d",a);
return 0;

}
