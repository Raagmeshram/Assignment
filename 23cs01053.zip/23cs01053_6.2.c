#include <stdio.h>

int main(){

short a = 32767;
printf("%d\n",a);
a++;
printf("%d\n",a);
a++;
printf("%d\n",a);
a++;
printf("%d",a);
return 0;

}