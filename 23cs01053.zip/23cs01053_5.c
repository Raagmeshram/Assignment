#include <stdio.h>

int main(){


printf("output a:\n");
printf("%4s\n", "a");
printf("%4s\n", "ab");
printf("%4s\n", "abc");
printf("%4s\n", "abcd");


printf("output b:\n");

printf("%04d\n", 1);
printf("%04d\n", 12);
printf("%04d\n", 123);
printf("%04d", 1234);







return 0;

}