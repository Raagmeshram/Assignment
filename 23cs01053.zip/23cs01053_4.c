#include <stdio.h>

int main(){

float e = 2.718281828;

printf("%.0f\n", e);
printf("%.0f.\n", e);
printf("%.1f\n", e);
printf("%.2f\n", e);
printf("%.3f\n", e);
printf("%.4f\n", e);
printf("%.5f\n", e);
printf("%.6f\n", e);
printf("%.7f\n", e);
return 0;

}