#include <stdio.h>

int main(){


printf("Raag Meshram\n");
printf("23cs01053\n");
printf("computer science");
return 0;

}

