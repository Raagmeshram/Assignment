#include <stdio.h>
#include<math.h>
int main(){

float e = 36.2323;
short int a = 34;
float remain;
remain = fmodf(e, (float)a);
printf("%f",remain);
return 0;

}