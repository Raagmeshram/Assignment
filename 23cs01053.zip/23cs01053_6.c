
#include <stdio.h>

int main(){

int a = 2147483647;
printf("%d\n",a);
a++;
printf("%d\n",a);
a++;
printf("%d\n",a);
a++;
printf("%d",a);
return 0;

}