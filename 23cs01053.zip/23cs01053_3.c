#include <stdio.h>

int main(){
int a = 69;
int b = 420;
int c = 999;

printf("%d\n",&a);
printf("%d\n",&b);
printf("%d",&c);
return 0;

}